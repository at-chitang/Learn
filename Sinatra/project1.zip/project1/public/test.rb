params= {"user_id"=>"1", "name"=>"sihc", "id"=>"1"}

section= [ params['user_id'], params['name'], "/#{params['user_id']}" ]

p section